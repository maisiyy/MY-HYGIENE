<?PHP	
$act 	= (isset($_POST['act'])) ? trim($_POST['act']) : '';	
$error = "";

if($act == "check")
{
	$q1		= $_POST['q1'];
	$q2		= (isset($_POST['q2'])) ? trim($_POST['q2']) : '';
	$q3 	= (isset($_POST['q3'])) ? trim($_POST['q3']) : '';
	
	if(($q1 ==1) && ($q2 ==0) && ($q3 ==0))
		print "<script> self.location='registration.php'; </script>";
	else
		$error = "We Advise You to Not Register As A Blood Donor";
}
?>
<!DOCTYPE html>
<html>
<title>Blood Donation System</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="w3.css">

<style>
a:link { text-decoration : none }

body,h1,h2,h3,h4,h5,h6 {font-family: "Arial", sans-serif}

body, html {
  height: 100%;
  line-height: 1.8;
}

/* Full height image header */
.bgimg-1 {
  background-position: top;
  background-size: cover;
  min-height: 100%;
  background-image: url(images/background.png);
}

.w3-bar .w3-button {
  padding: 16px;
}
</style>

<body>

<?PHP include("menu.php"); ?>


<div class="bgimg-1" >

	<div class="w3-padding-64"></div>
		
	<div class=" w3-center w3-text-white w3-padding-32">
		<a href="info1.php"><b>The Donation Process</b></a>
		&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		<a href="info2.php"><b>Why Donate Blood?</b></a>
	</div>


<div class="w3-container w3-padding-16" id="contact">
    <div class="w3-content w3-container w3-white w3-round-large w3-card" style="max-width:600px">
		<div class="w3-padding w3-margin">
			<form action="" method="post">
			  <div class="">
			  <h2 class="w3-center"><b>Register as a Donor!</b></h2>
			  
			<?PHP if($error) { ?> 
			<div class="w3-panel w3-red">
				  <h3>Sorry!</h3>
				  <p>We Advise You to Not Register As A Blood Donor.</p>
			</div>
			<?PHP } else { ?>

			  <b>Pre-Register </b>
			  <p>Please answer all the questions to check your eligibility criteria to donate blood.</p>
			  </div>

			  <div class="w3-section">
				<div class="w3-row">
				  <div class="w3-col s9 ">1. Are you 16 - 65 years old?</div>
				  <div class="w3-col s3 ">
					<input class="w3-radio" type="radio" name="q1" value="1" required>
					<label>Yes</label>
					&nbsp;&nbsp;
					<input class="w3-radio" type="radio" name="q1" value="0">
					<label>No</label>
				  </div>
				</div>
			  </div>
			  
			  <div class="w3-section">
				<div class="w3-row">
				  <div class="w3-col s9 ">2. Do you currently weight less than 50kg? </div>
				  <div class="w3-col s3 ">
					<input class="w3-radio" type="radio" name="q2" value="1" required>
					<label>Yes</label>
					&nbsp;&nbsp;
					<input class="w3-radio" type="radio" name="q2" value="0">
					<label>No</label>
				  </div>
				</div>
			  </div>
			  
			  <div class="w3-section">
				<div class="w3-row">
				  <div class="w3-col s9 ">3. Have you ever had a cancer?</div>
				  <div class="w3-col s3 ">
					<input class="w3-radio" type="radio" name="q3" value="1" required>
					<label>Yes</label>
					&nbsp;&nbsp;
					<input class="w3-radio" type="radio" name="q3" value="0">
					<label>No</label>
				  </div>
				</div>
			  </div>

			  <input type="hidden" name="act" value="check" >
			  <button type="submit" class="w3-button w3-block w3-padding-large w3-red w3-margin-bottom w3-round">Continue</button>
			  
			<?PHP } ?>
			</form>  
		</div>
    </div>
</div>



	
</div>

	
 
<script>

// Toggle between showing and hiding the sidebar when clicking the menu icon
var mySidebar = document.getElementById("mySidebar");

function w3_open() {
  if (mySidebar.style.display === 'block') {
    mySidebar.style.display = 'none';
  } else {
    mySidebar.style.display = 'block';
  }
}

// Close the sidebar with the close button
function w3_close() {
    mySidebar.style.display = "none";
}
</script>

</body>
</html>
