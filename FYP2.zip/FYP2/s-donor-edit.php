<?PHP
session_start();

include("database.php");
if( !verifyStaf($con) ) 
{
	header( "Location: index.php" );
	return false;
}
?>
<?PHP
$id_donor	= (isset($_REQUEST['id_donor'])) ? trim($_REQUEST['id_donor']) : '';
	
$act 		= (isset($_POST['act'])) ? trim($_POST['act']) : '';

$name		= (isset($_POST['name'])) ? trim($_POST['name']) : '';
$email		= (isset($_POST['email'])) ? trim($_POST['email']) : '';
$password	= (isset($_POST['password'])) ? trim($_POST['password']) : '';
$first_time = (isset($_POST['first_time'])) ? trim($_POST['first_time']) : '';
$phone		= (isset($_POST['phone'])) ? trim($_POST['phone']) : '';
$blood_type	= (isset($_POST['blood_type'])) ? trim($_POST['blood_type']) : '';
$weight		= (isset($_POST['weight'])) ? trim($_POST['weight']) : '';
$city		= (isset($_POST['city'])) ? trim($_POST['city']) : '';
$postcode	= (isset($_POST['postcode'])) ? trim($_POST['postcode']) : '';
$state		= (isset($_POST['state'])) ? trim($_POST['state']) : '';
$address	= (isset($_POST['address'])) ? trim($_POST['address']) : '';

$name		=	mysqli_real_escape_string($con, $name);

if($act == "update")
{	
	$SQL_insert = "
			UPDATE
				`donor`
			SET
				`name` = '$name',
				`email` = '$email',
				`password` = '$password',
				`first_time` = '$first_time',
				`phone` = '$phone',
				`blood_type` = '$blood_type',
				`weight` = '$weight',
				`city` = '$city',
				`postcode` = '$postcode',
				`state` = '$state]',
				`address` = '$address'
			WHERE
				`id_donor` = $id_donor";	
								
	$result = mysqli_query($con, $SQL_insert) or die("Error in query: ".$SQL_insert."<br />".mysqli_error($con));

	print "<script>alert('Succesfully Update'); self.location='s-donor.php';</script>";
}

$SQL_view 	= " SELECT * FROM `donor` WHERE `id_donor` =  '$id_donor' ";
$result 	= mysqli_query($con, $SQL_view) or die("Error in query: ".$SQL_view."<br />".mysqli_error($con));
$data		= mysqli_fetch_array($result);
?>
<!DOCTYPE html>
<html>
<title>Blood Donation System</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="w3.css">

<style>
a:link { text-decoration : none }

body,h1,h2,h3,h4,h5,h6 {font-family: "Arial", sans-serif}

body, html {
  height: 100%;
  line-height: 1.8;
}

/* Full height image header */
.bgimg-1 {
  background-position: top;
  background-size: cover;
  min-height: 100%;
  background-image: url(images/background.png);
}

.w3-bar .w3-button {
  padding: 16px;
}
</style>

<body>

<?PHP include("menu-staf.php"); ?>


<div class="bgimg-1" >

	<div class="w3-padding-64"></div>

<div class="w3-container w3-padding-16" id="contact">
    <div class="w3-content w3-container w3-white w3-round-large w3-card" style="max-width:600px">
		<div class="w3-padding w3-margin">
			<form action="" method="post">
			  <h3>Edit Donor</h3>
			    
			  <div class="w3-section" >
				<label></label>
				<input class="w3-input w3-border w3-round" type="text" name="name" placeholder="Name" value="<?PHP echo $data["name"]; ?>" required>
			  </div>
			  
			  <div class="w3-section">
				<label></label>
				<input class="w3-input w3-border w3-round" type="email" name="email" placeholder="Email" value="<?PHP echo $data["email"]; ?>" required>
			  </div>
			  
			  <div class="w3-section">
				<div class="w3-row">
				  <div class="w3-col s6 ">Is this your first time donating?</div>
				  <div class="w3-col s6 ">
					<input class="w3-radio" type="radio" name="first_time" value="1" <?PHP if($data["first_time"] == "1") echo "checked"; ?> required>
					<label>Yes</label>
					&nbsp;&nbsp;
					<input class="w3-radio" type="radio" name="first_time" value="0" <?PHP if($data["first_time"] == "0") echo "checked"; ?>>
					<label>No</label>
				  </div>
				</div>
			  </div>
			  
			  <div class="w3-section">
				<label></label>
				<input class="w3-input w3-border w3-round" type="password" name="password" placeholder="Password" value="<?PHP echo $data["password"]; ?>" required>
			  </div>
			  
			  <div class="w3-section">
				<label></label>
				<input class="w3-input w3-border w3-round" type="text" name="phone" placeholder="Phone No" value="<?PHP echo $data["phone"]; ?>" required>
			  </div>
			  
			  <div class="w3-section">
				<label></label>
				<input class="w3-input w3-border w3-round" type="text" name="blood_type" placeholder="Blood Type" value="<?PHP echo $data["blood_type"]; ?>" required>
			  </div>
			  
			  <div class="w3-section">
				<label></label>
				<input class="w3-input w3-border w3-round" type="text" name="weight" placeholder="Weight" value="<?PHP echo $data["weight"]; ?>" required>
			  </div>
			  
			  <div class="w3-section">
				<label></label>
				<textarea class="w3-input w3-border w3-round" name="address" placeholder="Address" required><?PHP echo $data["address"]; ?></textarea>
			  </div>
			  
			  <div class="w3-section">
				<label></label>
				<input class="w3-input w3-border w3-round" type="text" name="city" placeholder="City" value="<?PHP echo $data["city"]; ?>"  required>
			  </div>
			  
			  <div class="w3-section">
				<label></label>
				<input class="w3-input w3-border w3-round" type="text" name="postcode" placeholder="Postcode" value="<?PHP echo $data["postcode"]; ?>" required>
			  </div>
			  
			  <div class="w3-section">
				<label></label>
				<input class="w3-input w3-border w3-round" type="text" name="state" placeholder="State" value="<?PHP echo $data["state"]; ?>" required>
			  </div>
			  
			  <input type="hidden" name="id_donor" value="<?PHP echo $id_donor;?>" >
			  <input type="hidden" name="act" value="update" >
			  <button type="submit" class="w3-button w3-block w3-padding-large w3-red w3-margin-bottom w3-round">SAVE CHANGES</button>
			</form>  
		</div>
    </div>
</div>

<div class="w3-padding-64"></div>

	
</div>

	
 
<script>

// Toggle between showing and hiding the sidebar when clicking the menu icon
var mySidebar = document.getElementById("mySidebar");

function w3_open() {
  if (mySidebar.style.display === 'block') {
    mySidebar.style.display = 'none';
  } else {
    mySidebar.style.display = 'block';
  }
}

// Close the sidebar with the close button
function w3_close() {
    mySidebar.style.display = "none";
}
</script>

</body>
</html>
