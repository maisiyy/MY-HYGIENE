<!DOCTYPE html>
<html>
<title>Blood Donation System</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="w3.css">
<style>
a:link { text-decoration : none }

body,h1,h2,h3,h4,h5,h6 {font-family: "Arial", sans-serif}

body, html {
  height: 100%;
  line-height: 1.8;
}

/* Full height image header */
.bgimg-1 {
  background-position: top;
  background-size: cover;
  min-height: 100%;
  background-image: url(images/background.png);
}

.w3-bar .w3-button {
  padding: 16px;
}
</style>

<body>

<?PHP include("menu.php"); ?>


<div class="bgimg-1" >

	<div class="w3-padding-64"></div>
		
	<div class=" w3-center w3-text-white w3-padding-32">
		<a href="info1.php"><b>The Donation Process</b></a>
		&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		<a href="info2.php"><b>Why Donate Blood?</b></a>
	</div>


<div class="w3-container w3-padding-16" id="contact">
    <div class="w3-content w3-container w3-white w3-round-large w3-card" style="max-width:800px">
		<div class="w3-padding w3-margin">
			<div class="w3-xlarge w3-center"><b>Why Should People Donate Blood?</b></div>
			<p>
			Blood is life-saving. Women with complications during pregnancy and childbirth, children with severe anaemia, often caused by malaria or malnutrition, accident victims, and surgical and cancer patients all require blood.
			</p>
			<p>
			Even though blood can only be stored for a limited amount of time before use, a constant supply is required. A sufficient number of healthy people must donate blood on a regular basis to ensure that blood is always available whenever and wherever it is needed.
			</p>
			<p>
			Blood is the most valuable gift anyone can give another person - the gift of life. A decision to donate blood can save one or more lives if your blood is separated into its constituents - red cells, platelets, and plasma - which can be used individually for patients with specific conditions.
			</p>
			
			<a href="index.php" class="w3-button w3-block w3-padding-large w3-red w3-margin-bottom w3-round">&#10094; &nbsp; Back To Main</a>
		</div>
    </div>
</div>



	
</div>

	
 
<script>

// Toggle between showing and hiding the sidebar when clicking the menu icon
var mySidebar = document.getElementById("mySidebar");

function w3_open() {
  if (mySidebar.style.display === 'block') {
    mySidebar.style.display = 'none';
  } else {
    mySidebar.style.display = 'block';
  }
}

// Close the sidebar with the close button
function w3_close() {
    mySidebar.style.display = "none";
}
</script>

</body>
</html>
