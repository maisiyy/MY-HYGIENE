<?PHP
include("database.php");
	
$act 		= (isset($_POST['act'])) ? trim($_POST['act']) : '';

$name		= (isset($_POST['name'])) ? trim($_POST['name']) : '';
$email		= (isset($_POST['email'])) ? trim($_POST['email']) : '';
$password	= (isset($_POST['password'])) ? trim($_POST['password']) : '';
$first_time = (isset($_POST['first_time'])) ? trim($_POST['first_time']) : '';
$phone		= (isset($_POST['phone'])) ? trim($_POST['phone']) : '';
$blood_type	= (isset($_POST['blood_type'])) ? trim($_POST['blood_type']) : '';
$weight		= (isset($_POST['weight'])) ? trim($_POST['weight']) : '';
$city		= (isset($_POST['city'])) ? trim($_POST['city']) : '';
$postcode	= (isset($_POST['postcode'])) ? trim($_POST['postcode']) : '';
$state		= (isset($_POST['state'])) ? trim($_POST['state']) : '';
$address	= (isset($_POST['address'])) ? trim($_POST['address']) : '';

$name		=	mysqli_real_escape_string($con, $name);

if($act == "register")
{	
	$SQL_insert = "
	INSERT INTO `donor`(`name`, `email`, `password`, `first_time`, `phone`, `blood_type`, 
						`weight`, `city`, `postcode`, `state`, `address`, `created_date`) 
			VALUES ('$name', '$email', '$password', '$first_time', '$phone', '$blood_type', 
					'$weight', '$city', '$postcode', '$state', '$address', NOW())";	
	//echo 	$SQL_insert; exit;									
	$result = mysqli_query($con, $SQL_insert) or die("Error in query: ".$SQL_insert."<br />".mysqli_error($con));

	print "<script>alert('Thank You For Registering With Us!.'); 
	self.location='main.php' ;</script>";
}
?>
<!DOCTYPE html>
<html>
<title>Blood Donation System</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="w3.css">

<style>
a:link { text-decoration : none }

body,h1,h2,h3,h4,h5,h6 {font-family: "Arial", sans-serif}

body, html {
  height: 100%;
  line-height: 1.8;
}

/* Full height image header */
.bgimg-1 {
  background-position: top;
  background-size: cover;
  min-height: 100%;
  background-image: url(images/background.png);
}

.w3-bar .w3-button {
  padding: 16px;
}
</style>

<body>

<?PHP include("menu.php"); ?>


<div class="bgimg-1" >

	<div class="w3-padding-64"></div>
		
	<div class=" w3-center w3-text-white w3-padding-32">
		<a href="info1.php"><b>The Donation Process</b></a>
		&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		<a href="info2.php"><b>Why Donate Blood?</b></a>
	</div>


<div class="w3-container w3-padding-16" id="contact">
    <div class="w3-content w3-container w3-white w3-round-large w3-card" style="max-width:600px">
		<div class="w3-padding w3-margin">
			<form action="" method="post">
			  <div class="w3-center">
			  <h2 class=""><b>Blood Donation Form</b></h2>
			  
			  <b>Please answer the following questions correctly. This will help to protect you and the patient who receives the blood</b>
			  </div>
			    
			  <div class="w3-section" >
				<label></label>
				<input class="w3-input w3-border w3-round" type="text" name="name" placeholder="Name"  required>
			  </div>
			  
			  <div class="w3-section">
				<label></label>
				<input class="w3-input w3-border w3-round" type="email" name="email" placeholder="Email" required>
			  </div>
			  
			  <div class="w3-section">
				<div class="w3-row">
				  <div class="w3-col s6 ">Is this your first time donating?</div>
				  <div class="w3-col s6 ">
					<input class="w3-radio" type="radio" name="first_time" value="1" required>
					<label>Yes</label>
					&nbsp;&nbsp;
					<input class="w3-radio" type="radio" name="first_time" value="0">
					<label>No</label>
				  </div>
				</div>
			  </div>
			  
			  <div class="w3-section">
				<label></label>
				<input class="w3-input w3-border w3-round" type="password" name="password" placeholder="Password" required>
			  </div>
			  
			  <div class="w3-section">
				<label></label>
				<input class="w3-input w3-border w3-round" type="text" name="phone" placeholder="Phone No" required>
			  </div>
			  
			  <div class="w3-section">
				<label></label>
				<input class="w3-input w3-border w3-round" type="text" name="blood_type" placeholder="Blood Type" required>
			  </div>
			  
			  <div class="w3-section">
				<label></label>
				<input class="w3-input w3-border w3-round" type="text" name="weight" placeholder="Weight" required>
			  </div>
			  
			  <div class="w3-section">
				<label></label>
				<textarea class="w3-input w3-border w3-round" name="address" placeholder="Address" required></textarea>
			  </div>
			  
			  <div class="w3-section">
				<label></label>
				<input class="w3-input w3-border w3-round" type="text" name="city" placeholder="City" required>
			  </div>
			  
			  <div class="w3-section">
				<label></label>
				<input class="w3-input w3-border w3-round" type="text" name="postcode" placeholder="Postcode" required>
			  </div>
			  
			  <div class="w3-section">
				<label></label>
				<input class="w3-input w3-border w3-round" type="text" name="state" placeholder="State" required>
			  </div>
			  
			  <input type="hidden" name="act" value="register" >
			  <button type="submit" class="w3-button w3-block w3-padding-large w3-red w3-margin-bottom w3-round">SUBMIT</button>
			</form>  
		</div>
    </div>
</div>

<div class="w3-padding-64"></div>

	
</div>

	
 
<script>

// Toggle between showing and hiding the sidebar when clicking the menu icon
var mySidebar = document.getElementById("mySidebar");

function w3_open() {
  if (mySidebar.style.display === 'block') {
    mySidebar.style.display = 'none';
  } else {
    mySidebar.style.display = 'block';
  }
}

// Close the sidebar with the close button
function w3_close() {
    mySidebar.style.display = "none";
}
</script>

</body>
</html>
