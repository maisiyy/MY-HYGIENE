<?PHP
session_start();

include("database.php");
if( !verifyAdmin($con) ) 
{
	header( "Location: index.php" );
	return false;
}
?>
<?PHP
$act 		= (isset($_GET['act'])) ? trim($_GET['act']) : '';	
$id_staf	= (isset($_GET['id_staf'])) ? trim($_GET['id_staf']) : '';	

if($act == "del")
{
	$SQL_delete = " DELETE FROM `staf` WHERE `id_staf` =  '$id_staf' ";
	$result = mysqli_query($con, $SQL_delete) or die("Error in query: ".$SQL_delete."<br />".mysqli_error($con));
	
	print "<script>self.location='a-main.php';</script>";
}
?>
<!DOCTYPE html>
<html>
<title>Blood Donation System</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="w3.css">

<style>
body,h1,h2,h3,h4,h5,h6 {font-family: "Arial", sans-serif}

body, html {
  height: 100%;
  line-height: 1.8;
}

/* Full height image header */
.bgimg-1 {
  background-position: top;
  background-size: cover;
  background-image: url("images/background.png");
  min-height: 100%;
}

.w3-bar .w3-button {
  padding: 16px;
}
</style>

<body>

<?PHP include("menu-admin.php"); ?>



<div class="bgimg-1" >

	<div class="w3-padding-64"></div>
	
	
	<div class="w3-container w3-padding-16" id="contact">
    <div class="w3-content w3-container w3-white w3-round-large w3-card" style="max-width:1000px">
		<div class="w3-padding w3-margin">
			<div class="w3-xlarge w3-center"><b>Manage Staf</b></div>
			
			<div class="w3-padding-16"></div>

			<div class="w3-padding-16"><a href="a-staf-add.php" class="w3-button w3-red w3-round"><i class="fa fa-fw fa-plus"></i> Add Staf</a></div>
			<div class="table-responsive  w3-responsive">
				<table class="w3-table w3-table-all table-bordered" id="dataTable" width="100%" cellspacing="0">
					<thead>
						<tr>
							<th>Staf ID</th>
							<th>Name</th>
							<th>Username</th>
							<th>Position</th>
							<th>Phone</th>
							<th>Action</th>
						</tr>
					</thead>
					<tbody>
					
					<?PHP
					$bil = 0;

					$SQL_staf = "SELECT * FROM `staf` ";

					$result = mysqli_query($con, $SQL_staf) or die("Error in query: ".$SQL_staf."<br />".mysqli_error($con));

					while ( $data	= mysqli_fetch_array($result) )
					{
						$bil++; 
					?>
						<tr>
							<td><?PHP echo $data["id_staf"]; ?></td>
							<td><?PHP echo $data["name"]; ?></td>
							<td><?PHP echo $data["username"]; ?></td>
							<td><?PHP echo $data["position"]; ?></td>
							<td><?PHP echo $data["phone"]; ?></td>
							<td>
							<a href="a-staf-edit.php?id_staf=<?PHP echo $data["id_staf"]; ?>" class="w3-button w3-small w3-blue w3-round">Edit </a>

							<a onclick="return confirm('Are you sure ?');" href="?act=del&id_staf=<?PHP echo $data["id_staf"]; ?>" class="w3-button w3-small w3-red w3-round"	>Del </a>
							</td>
						</tr>
					<?PHP
					
					}
					?>

					</tbody>
				</table>
				
				 <p>&nbsp;</p>
			</div>
			
		</div>
    </div>
</div>
	
	<div class="w3-padding-64"></div>
	
</div>

 
<script>

// Toggle between showing and hiding the sidebar when clicking the menu icon
var mySidebar = document.getElementById("mySidebar");

function w3_open() {
  if (mySidebar.style.display === 'block') {
    mySidebar.style.display = 'none';
  } else {
    mySidebar.style.display = 'block';
  }
}

// Close the sidebar with the close button
function w3_close() {
    mySidebar.style.display = "none";
}
</script>

</body>
</html>
