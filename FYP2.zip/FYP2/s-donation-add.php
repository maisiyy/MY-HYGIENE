<?PHP
session_start();

include("database.php");
if( !verifyStaf($con) ) 
{
	header( "Location: index.php" );
	return false;
}
?>
<?PHP	
$act 			= (isset($_POST['act'])) ? trim($_POST['act']) : '';	
$id_donor 		= (isset($_POST['id_donor'])) ? trim($_POST['id_donor']) : '';
$date_donate	= (isset($_POST['date_donate'])) ? trim($_POST['date_donate']) : '';
$blood_series	= (isset($_POST['blood_series'])) ? trim($_POST['blood_series']) : '';
$blood_type		= (isset($_POST['blood_type'])) ? trim($_POST['blood_type']) : '';
$amount			= (isset($_POST['amount'])) ? trim($_POST['amount']) : '';
$venue			= (isset($_POST['venue'])) ? trim($_POST['venue']) : '';

$name	=	mysqli_real_escape_string($con, $name);


if($act == "add")
{	
	$SQL_insert = " 
	INSERT INTO `donation`(`id_donor`, `date_donate`, `blood_series`, 
							`blood_type`, `amount`,`venue`, `created_date`) 
					VALUES ('$id_donor', '$date_donate', '$blood_series', 
							'$blood_type', '$amount','$venue', NOW())";	
										
	$result = mysqli_query($con, $SQL_insert) or die("Error in query: ".$SQL_insert."<br />".mysqli_error($con));
	
	print "<script>alert('Successfully Add'); self.location='s-main.php';</script>";
}
?>
<!DOCTYPE html>
<html>
<title>Blood Donation System</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="w3.css">


<style>
a {
  text-decoration: none;
}

body,h1,h2,h3,h4,h5,h6 {font-family: "Arial", sans-serif}

body, html {
  height: 100%;
  line-height: 1.8;
}

/* Full height image header */
.bgimg-1 {
  background-position: top;
  background-size: cover;
  background-image: url("images/background.png");
  min-height: 100%;
}

.w3-bar .w3-button {
  padding: 16px;
}
</style>

<body>

<?PHP include("menu-staf.php"); ?>

<div class="bgimg-1" >

	<div class="w3-padding-64"></div>
		
	
<div class="w3-container w3-padding" id="contact">
    <div class="w3-content w3-container w3-white w3-round w3-card" style="max-width:600px">
		<div class="w3-padding">
		
			<form method="post" action="" >
				<h3>Add Donation</h3>
			
				<div class="w3-section" >
					<label>Donor ID *</label>
					<select class="w3-select w3-border w3-round" name="id_donor"  required>
					<?PHP
					$result = mysqli_query($con, "SELECT * FROM `donor`") ;
					while ( $data = mysqli_fetch_array($result) )
					{				
						echo "<option value='". $data["id_donor"]. "'>". $data["id_donor"] . " - " . $data["name"]. "</option>";
					}
					?>
					</select>
				</div>

				<div class="w3-section" >
					<label>Date Donate *</label>
					<input class="w3-input w3-border w3-round" type="date" name="date_donate"  required>
				</div>
				
				<div class="w3-section" >
					<label>Blood Series *</label>
					<input class="w3-input w3-border w3-round" type="text" name="blood_series"  required>
				</div>
				
				<div class="w3-section" >
					<label>Blood Type </label>
					<input class="w3-input w3-border w3-round" type="text" name="blood_type"  >
				</div>
				
				<div class="w3-section" >
					<label>Amount *</label>
					<input class="w3-input w3-border w3-round" type="text" name="amount"  required>
				</div>
				
				<div class="w3-section" >
					<label>Venue</label>
					<input class="w3-input w3-border w3-round" type="text" name="venue"  required>
				</div>

				<hr class="w3-clear">
				<input type="hidden" name="act" value="add" >
				<button type="submit" class="w3-button w3-block w3-padding-large w3-red w3-margin-bottom w3-round">SUBMIT</button>
				

			</form>
		</div>
    </div>
</div>


<div class="w3-padding-64"></div>
	
</div>



<script>

// Toggle between showing and hiding the sidebar when clicking the menu icon
var mySidebar = document.getElementById("mySidebar");

function w3_open() {
  if (mySidebar.style.display === 'faculty') {
    mySidebar.style.display = 'none';
  } else {
    mySidebar.style.display = 'faculty';
  }
}

// Close the sidebar with the close button
function w3_close() {
    mySidebar.style.display = "none";
}
</script>

</body>
</html>