<?PHP
session_start();

include("database.php");

$act 		= (isset($_POST['act'])) ? trim($_POST['act']) : '';

if($act == "login")
{
	$level		= (isset($_POST['level'])) ? trim($_POST['level']) : '';
	$username	= (isset($_POST['username'])) ? trim($_POST['username']) : '';
	$password 	= (isset($_POST['password'])) ? trim($_POST['password']) : '';

	if($level == "donor") 
	{
		$SQL_login = " SELECT * FROM `donor` WHERE `email` = '$username' AND `password` = '$password'  ";
	}

	if($level == "staf") 
	{
		$SQL_login = " SELECT * FROM `staf` WHERE `username` = '$username' AND `password` = '$password'  ";
	}
	
	if($level == "admin") 
	{
		$SQL_login = " SELECT * FROM `admin` WHERE `username` = '$username' AND `password` = '$password'  ";
	}

	$result = mysqli_query($con, $SQL_login) or die("Error in query: ".$SQL_login."<br />".mysqli_error($con));
	$data	= mysqli_fetch_array($result);

	$valid = mysqli_num_rows($result);

	if($valid > 0)
	{
		$_SESSION["password"] 	= $password;

		if($level == "admin") {
			$_SESSION["username"] = $username;
			// admin main page
			header("Location:a-main.php");
		}
		
		if($level == "staf") {
			$_SESSION["username"] = $username;
			// staff main page
			header("Location:s-main.php");
		}
		
		if($level == "donor") {
			$_SESSION["email"] = $username;
			$_SESSION["id_donor"] = $data["id_donor"];
			// donor main page
			header("Location:main.php");
		}
	}else{
		//header( "refresh:1;url=index.php" );
		print "<script>alert('Login is invalid!'); self.location='index.php';</script>";
	}

}
?>
<!DOCTYPE html>
<html>
<title>Blood Donation System</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="w3.css">

<style>
a:link { text-decoration : none }

body,h1,h2,h3,h4,h5,h6 {font-family: "Arial", sans-serif}

body, html {
  height: 100%;
  line-height: 1.8;
}

/* Full height image header */
.bgimg-1 {
  background-position: top;
  background-size: cover;
  min-height: 100%;
  background-image: url(images/background.png);
}

.w3-bar .w3-button {
  padding: 16px;
}
</style>

<body>

<?PHP include("menu.php"); ?>


<div class="bgimg-1" >

	<div class="w3-padding-64"></div>
		
	<div class=" w3-center w3-text-white w3-padding-32">
		<a href="info1.php"><b>The Donation Process</b></a>
		&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		<a href="info2.php"><b>Why Donate Blood?</b></a>
	</div>


<div class="w3-container w3-padding-16" id="contact">
    <div class="w3-content w3-container w3-white w3-round-large w3-card" style="max-width:600px">
		<div class="w3-padding w3-margin">
			<form action="" method="post">
			  <div class="w3-center">
			  <h2 class=""><b>LOG IN</b></h2>
			  
			  <b>Dont have an account? <a href="signup.php" class="w3-text-blue">Sign Up Here</a></b>
			  </div>
			  
			  <div class="w3-section">
				<label></label>
				<select class="w3-select w3-input w3-border w3-round" name="level" id="level" required>
					<option value="donor" >Donor</option>
					<option value="staf" >Staf</option>
					<option value="admin" >Admin</option>
				</select>
			   </div>
			   
			   
			  <div class="w3-section" >
				<label></label>
				<input class="w3-input w3-border w3-round" type="text" name="username" placeholder="Email"  required>
			  </div>
			  <div class="w3-section">
				<label></label>
				<input class="w3-input w3-border w3-round" type="password" name="password" placeholder="Password" required>
			  </div>
			  
			  <input type="hidden" name="act" value="login" >
			  <button type="submit" class="w3-button w3-block w3-padding-large w3-red w3-margin-bottom w3-round">LOGIN</button>
			</form>  
		</div>
    </div>
</div>



	
</div>

	
 
<script>

// Toggle between showing and hiding the sidebar when clicking the menu icon
var mySidebar = document.getElementById("mySidebar");

function w3_open() {
  if (mySidebar.style.display === 'block') {
    mySidebar.style.display = 'none';
  } else {
    mySidebar.style.display = 'block';
  }
}

// Close the sidebar with the close button
function w3_close() {
    mySidebar.style.display = "none";
}
</script>

</body>
</html>
