<?PHP
session_start();

include("database.php");
if( !verifyStaf($con) ) 
{
	header( "Location: index.php" );
	return false;
}
?>
<?PHP
$act 		= (isset($_GET['act'])) ? trim($_GET['act']) : '';	
$id_donor	= (isset($_GET['id_donor'])) ? trim($_GET['id_donor']) : '';	

if($act == "del")
{
	$SQL_delete = " DELETE FROM `donation` WHERE `id_donor` =  '$id_donor' ";
	$result = mysqli_query($con, $SQL_delete) or die("Error in query: ".$SQL_delete."<br />".mysqli_error($con));
	
	print "<script>self.location='s-main.php';</script>";
}
?>
<!DOCTYPE html>
<html>
<title>Blood Donation System</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="w3.css">

<style>
body,h1,h2,h3,h4,h5,h6 {font-family: "Arial", sans-serif}

body, html {
  height: 100%;
  line-height: 1.8;
}

/* Full height image header */
.bgimg-1 {
  background-position: top;
  background-size: cover;
  background-image: url("images/background.png");
  min-height: 100%;
}

.w3-bar .w3-button {
  padding: 16px;
}
</style>

<body>

<?PHP include("menu-staf.php"); ?>



<div class="bgimg-1" >

	<div class="w3-padding-64"></div>
	
	
	<div class="w3-container w3-padding-16" id="contact">
    <div class="w3-content w3-container w3-white w3-round-large w3-card" style="max-width:1000px">
		<div class="w3-padding w3-margin">
			<div class="w3-xlarge w3-center"><b>Donation Record</b></div>
			
			<div class="w3-padding-16"></div>

			<div class="w3-padding-16"><a href="s-donation-add.php" class="w3-button w3-red w3-round"><i class="fa fa-fw fa-plus"></i> Add Donation</a></div>
			<div class="table-responsive  w3-responsive">
				<table class="w3-table w3-table-all table-bordered" id="dataTable" width="100%" cellspacing="0">
					<thead>
						<tr>
							<th>#</th>
							<th>Donor ID</th>
							<th>Date Donate</th>
							<th>Blood Series No</th>
							<th>Blood Type</th>
							<th>Amount</th>
							<th>Venue</th>
							<th>Action</th>
						</tr>
					</thead>
					<tbody>
					
					<?PHP
					$bil = 0;

					$SQL_donate = "SELECT * FROM `donation` ";

					$result = mysqli_query($con, $SQL_donate) or die("Error in query: ".$SQL_donate."<br />".mysqli_error($con));

					while ( $data	= mysqli_fetch_array($result) )
					{
						$bil++; 
					?>
						<tr>
							<td><?PHP echo $bil; ?></td>
							<td><?PHP echo $data["id_donor"]; ?></td>
							<td><?PHP echo $data["date_donate"]; ?></td>
							<td><?PHP echo $data["blood_series"]; ?></td>
							<td><?PHP echo $data["blood_type"]; ?></td>
							<td><?PHP echo $data["amount"]; ?></td>
							<td><?PHP echo $data["venue"]; ?></td>
							<td>
							<a onclick="return confirm('Are you sure ?');" href="?act=del&id_donor=<?PHP echo $data["id_donor"]; ?>" class="w3-button w3-small w3-red w3-round"	>Del </a>
							</td>
						</tr>
					<?PHP
					
					}
					?>

					</tbody>
				</table>
				
				 <p>&nbsp;</p>
			</div>
			
		</div>
    </div>
</div>
	
	<div class="w3-padding-64"></div>
	
</div>

 
<script>

// Toggle between showing and hiding the sidebar when clicking the menu icon
var mySidebar = document.getElementById("mySidebar");

function w3_open() {
  if (mySidebar.style.display === 'block') {
    mySidebar.style.display = 'none';
  } else {
    mySidebar.style.display = 'block';
  }
}

// Close the sidebar with the close button
function w3_close() {
    mySidebar.style.display = "none";
}
</script>

</body>
</html>
